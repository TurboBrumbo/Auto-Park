Сайт: https://apex.oracle.com/en/
Sign In
WorkSpace: kirill
Username: nkv17@outlook.com
Password: nkv17012002
App Builder (Самая первая кнопка)
Далее будут три приложения, Cars, Drivers, Trips, которые нужно запустить, чтобы просмотреть дашборды
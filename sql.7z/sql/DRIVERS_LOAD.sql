BEGIN
    TRUNCATE TABLE DRIVERS;    -- очистка таблицы

    INSERT into DRIVERS (ID    -- добавление необходимых записей
    ,INITIALS
    ,AGE
    ,EXPERIENCE
    ,RATING)
    
   WITH B AS (SELECT DRIVER_ID, SUM(RATING)/COUNT(*) AS AVG_RATING FROM TRIPS
        GROUP BY  DRIVER_ID) 
SELECT 
    A.ID
   ,A.INITIALS
   ,A.AGE
   ,A.EXPERIENCE
   ,B.AVG_RATING 
   FROM 
        DRIVERS_PRE A
        LEFT JOIN B
        ON A.ID = B.DRIVER_ID
END;